<?php
	$servidor = "localhost";
	$usuario = "root";
	$senha = "";
	$dbname = "celke";
	
	//Criar a conexão
	$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);
?>